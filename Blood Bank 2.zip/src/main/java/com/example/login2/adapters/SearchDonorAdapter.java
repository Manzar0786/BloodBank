package com.example.login2.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login2.R;
import com.example.login2.viewmodels.DonorData;

import java.util.List;

public class SearchDonorAdapter extends RecyclerView.Adapter<SearchDonorAdapter.PostHolder> {

    private List<DonorData> postList;

    public class PostHolder extends RecyclerView.ViewHolder{
        TextView name, address, contact, posted, totaldonate;
        Button btnSearch;
        public PostHolder(View itemView){
            super(itemView);

            name=itemView.findViewById(R.id.donorName);
            address=itemView.findViewById(R.id.donorAddress);
            contact=itemView.findViewById(R.id.donorContact);
            posted=itemView.findViewById(R.id.lastDonate);
            totaldonate=itemView.findViewById(R.id.totalDonate);

        }
    }

    public SearchDonorAdapter(List<DonorData> postList){
        this.postList=postList;
    }

    @NonNull
    @Override
    public PostHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View listitem= LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.search_donor_item, viewGroup , false);

        return new PostHolder(listitem);
    }

    @Override
    public void onBindViewHolder(@NonNull PostHolder postHolder, int i) {

        if(i%2==0)
        {postHolder.itemView.setBackgroundColor(Color.parseColor("#C13F31"));}
        else
        {postHolder.itemView.setBackgroundColor(Color.parseColor("#F8F8F8"));}

        DonorData donorData=postList.get(i);
        postHolder.name.setText("Name: "+donorData.getName());
        postHolder.address.setText("Address: "+donorData.getAddress());
        postHolder.contact.setText("Contact: "+donorData.getContact());
        postHolder.posted.setText("Posted on: "+donorData.getLastDonate());
        postHolder.totaldonate.setText("Last Donation: "+donorData.getTotalDonate()+" times");

    }

    @Override
    public int getItemCount() {
        return postList.size();
    }
}
