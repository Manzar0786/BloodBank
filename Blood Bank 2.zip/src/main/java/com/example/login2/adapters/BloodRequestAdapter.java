package com.example.login2.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login2.R;
import com.example.login2.viewmodels.CustomerUserData;

import org.jetbrains.annotations.NotNull;

import java.io.LineNumberInputStream;
import java.util.List;

public class BloodRequestAdapter extends RecyclerView.Adapter<BloodRequestAdapter.PostHolder> {

    private List<CustomerUserData> postList;

    public class PostHolder extends RecyclerView.ViewHolder{
        TextView name, bloodgroup, address, contact, posted;

        public PostHolder(@NotNull View itemView){
            super(itemView);

            name=itemView.findViewById(R.id.reqstUser);
            bloodgroup=itemView.findViewById(R.id.targetBG);
            address=itemView.findViewById(R.id.reqstLocation);
            contact=itemView.findViewById(R.id.targetCN);
            posted=itemView.findViewById(R.id.posted);
        }
    }

    public BloodRequestAdapter(List<CustomerUserData> postList){
        this.postList=postList;
    }

    @Override
    public PostHolder onCreateViewHolder( ViewGroup viewGroup, int i) {
        View listitem= LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.request_list_item,viewGroup,false);
        return new PostHolder(listitem);
    }

    @Override
    public void onBindViewHolder(@NonNull PostHolder postHolder, int i) {

        if(i%2==0)
            postHolder.itemView.setBackgroundColor(Color.parseColor("#C13F31"));
        else
            postHolder.itemView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        CustomerUserData customerUserData=postList.get(i);
        postHolder.name.setText("Posted by: "+customerUserData.getName());
        postHolder.bloodgroup.setText("Needs: "+customerUserData.getBloodGroup());
        postHolder.address.setText("From: "+customerUserData.getAddress()+", "+customerUserData.getDivision());
        postHolder.contact.setText(customerUserData.getContact());
        postHolder.posted.setText("Posted on: "+customerUserData.getTime()+", "+customerUserData.getDate());
    }

    @Override
    public int getItemCount() {
        return postList.size();
    }
}
