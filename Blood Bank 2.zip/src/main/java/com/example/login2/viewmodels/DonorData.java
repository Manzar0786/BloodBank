package com.example.login2.viewmodels;

import com.google.android.material.badge.BadgeDrawable;

public class DonorData {
    private int TotalDonate;
    private String LastDonate,Name,Contact,UID,Address;

    public DonorData(){
    }

    public DonorData(int totalDonate, String lastDonate, String name, String contact, String UID,String address){
        this.TotalDonate=totalDonate;
        this.LastDonate=lastDonate;
        this.Name=name;
        this.Contact=contact;
        this.UID=UID;
        this.Address=address;
    }

    public int getTotalDonate(){ return TotalDonate; }

    public void setTotalDonate(int totalDonate){ this.TotalDonate=totalDonate; }

    public String getLastDonate(){ return LastDonate; }

    public void setLastDonate(String lastDonate){ this.LastDonate=lastDonate; }

    public String getName(){ return Name; }

    public void setName(String name){ this.Name=name; }

    public String getContact(){ return Contact; }

    public void setContact(String contact){ this.Contact=contact; }

    public String getUID(){ return UID; }

    public void setUID(String UID){ this.UID=UID; }

    public String getAddress(){ return Address; }

    public void setAddress(String address){ this.Address=address; }
}
