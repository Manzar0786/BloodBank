package com.example.login2.viewmodels;

import android.os.AsyncTask;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.shape.MarkerEdgeTreatment;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class GetNearByPlacesData extends AsyncTask<Object,String,String> {

    String googlePlacesData;
     GoogleMap googleMap;
    String url;
    @Override
    protected String doInBackground(Object... objects) {
        googleMap=(GoogleMap) objects[0];
        url=(String) objects[1];

        DownloadUrl downloadUrl=new DownloadUrl();
        try{
            googlePlacesData=downloadUrl.readUrl(url);
        }catch (IOException e){
            e.printStackTrace();
        }
        return googlePlacesData;
    }

    @Override
    protected void onPostExecute(String s) {
        List<HashMap<String,String>> nearbyPlaceList;
        DataParser parser=new DataParser();
        nearbyPlaceList=parser.parse(s);

        showNearbyPlaces(nearbyPlaceList);
    }

    private void showNearbyPlaces(List<HashMap<String , String>> nearbyPlaces){
        for(int i=0;i<nearbyPlaces.size();i++){
            MarkerOptions markerOptions=new MarkerOptions();
            HashMap<String , String> googlePlace=nearbyPlaces.get(i);

            String PlaceName=googlePlace.get("Place_Name");
            String Vicinity=googlePlace.get("Vicinity");
            double lat=Double.parseDouble(googlePlace.get("lat"));
            double lng=Double.parseDouble(googlePlace.get("lng"));

            LatLng latLng=new LatLng(lat,lng);
            markerOptions.position(latLng);
            markerOptions.title(PlaceName+" "+Vicinity);
            markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));

            googleMap.addMarker(markerOptions);
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            googleMap.moveCamera(CameraUpdateFactory.zoomBy(10));
        }
    }
}
