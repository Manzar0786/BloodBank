package com.example.login2.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.login2.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    private EditText inputemail,inputpassword;
    private Button btnlogin,btnregister,btnforgotpass;
    private FirebaseAuth mAuth;
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pd=new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(false);

        mAuth=FirebaseAuth.getInstance();
        if(mAuth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),Dashboard.class));
            finish();
        }

        inputemail=findViewById(R.id.input_username);
        inputpassword=findViewById(R.id.input_password);

        btnlogin=findViewById(R.id.button_login);
        btnregister=findViewById(R.id.button_register);
        btnforgotpass=findViewById(R.id.button_forgot_password);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email=inputemail.getText().toString()+"";
                final String password=inputpassword.getText().toString()+"";

                try{
                    if(password.length()>0 && email.length()>0){
                        pd.show();
                        mAuth.signInWithEmailAndPassword(email,password)
                                .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if(task.isSuccessful()){
                                            startActivity(new Intent(getApplicationContext(),Dashboard.class));
                                            finish();
                                        }else{
                                            Toast.makeText(getApplicationContext(), "Authentication Failed!", Toast.LENGTH_SHORT)
                                                    .show();
                                            Log.v("Error",task.getException().getMessage());

                                        }
                                        pd.dismiss();
                                    }
                                });
                    }else{
                        Toast.makeText(LoginActivity.this, "Please fill all the field.", Toast.LENGTH_SHORT).show();
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(LoginActivity.this, ProfileActivity.class);
                startActivity(i);
                finish();
            }
        });

        btnforgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RestorePassword.class));
                finish();
            }
        });
    }
}