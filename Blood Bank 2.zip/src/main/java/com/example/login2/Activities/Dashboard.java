package com.example.login2.Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;

import com.example.login2.R;
import com.example.login2.fragments.AboutUs;
import com.example.login2.fragments.AchievementsView;
import com.example.login2.fragments.BloodInfo;
import com.example.login2.fragments.HomeView;
import com.example.login2.fragments.NearByHospital;
import com.example.login2.fragments.SearchDonor;
import com.example.login2.viewmodels.UserData;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Objects;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth mAuth;
    private TextView getUserName;
    private TextView getUserEmail;
    private FirebaseDatabase user_db;
    private FirebaseUser cur_user;
    private DatabaseReference userdb_ref;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        pd = new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(false);

        mAuth=FirebaseAuth.getInstance();
        user_db=FirebaseDatabase.getInstance();
        cur_user=mAuth.getCurrentUser();
        userdb_ref=user_db.getReference("Users");

        getUserEmail=findViewById(R.id.UserEmailView);
        getUserName=findViewById(R.id.UserNameView);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Dashboard.this,PostActivity.class));
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header=navigationView.getHeaderView(0);

        getUserEmail=header.findViewById(R.id.UserEmailView);
        getUserName=header.findViewById(R.id.UserNameView);

        Query singleuser=userdb_ref.child(cur_user.getUid());
        pd.show();
        singleuser.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               // String name= Objects.requireNonNull(dataSnapshot.getValue(UserData.class)).getName();
                // getUserName.setText(dataSnapshot.getValue(UserData.class).getName());
                getUserEmail.setText(cur_user.getEmail());

                pd.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("user", databaseError.getMessage());
            }
        });
        if(savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer, new HomeView()).commit();
            navigationView.getMenu().getItem(0).setChecked(true);
        }

    }

    @Override
    public void onBackPressed(){
        DrawerLayout drawer=(DrawerLayout)findViewById(R.id.drawer_layout);
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.dashboard,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id=item.getItemId();
        if(id==R.id.donateInfo){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer, new BloodInfo()).commit();
        }
        if(id==R.id.devinfo){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,new AboutUs()).commit();
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item){
        int id=item.getItemId();
        if(id == R.id.home){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,new HomeView()).commit();

        }else if(id==R.id.userprofile){
            startActivity(new Intent(getApplicationContext(),ProfileActivity.class));

        }else if(id==R.id.user_achiev){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,new AchievementsView()).commit();

        }else if(id==R.id.logout){
            mAuth.signOut();
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));

        }else if(id==R.id.blood_storage){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer, new SearchDonor()).commit();

        }else if(id==R.id.nearby_hospital){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,new NearByHospital()).commit();

        }else if(id==R.id.blood_info){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentcontainer,new BloodInfo()).commit();
        }
        DrawerLayout drawer=findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onStart(){
        super.onStart();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if(currentUser == null){
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));
            finish();
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        FirebaseUser currentUser=mAuth.getCurrentUser();
        if(currentUser==null){
            startActivity(new Intent(getApplicationContext(),LoginActivity.class));
            finish();
        }
    }
}