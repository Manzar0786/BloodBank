package com.example.login2.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.login2.Activities.LoginActivity;
import com.example.login2.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RestorePassword extends AppCompatActivity {
    Button resetbtn;
    EditText useremail;
    private FirebaseAuth mAuth;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restore_password);

        mAuth=FirebaseAuth.getInstance();
        pd=new ProgressDialog(this);
        pd.setMessage("Loading...");
        pd.setCancelable(true);
        pd.setCanceledOnTouchOutside(false);

        resetbtn=findViewById(R.id.resetPassbtn);
        useremail=findViewById(R.id.resetUsingEmail);

        resetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseUser user=mAuth.getCurrentUser();

                final String email=useremail.getText().toString();

                if(TextUtils.isEmpty(email)){
                    useremail.setError("Email required!");
                }else{

                    pd.show();

                    mAuth.sendPasswordResetEmail(email)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(getApplicationContext(), "We have sent email to"+email+"PLease chek your email", Toast.LENGTH_SHORT)
                                                .show();
                                        startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                                    }else{
                                        Toast.makeText(getApplicationContext(), "Sorry, there is something went wrong , please try some time later.", Toast.LENGTH_SHORT)
                                                .show();
                                        useremail.setText(null);
                                    }
                                    pd.dismiss();
                                }
                            });
                }
            }
        });
    }
}